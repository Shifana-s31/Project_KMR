from django.http import HttpResponse
from django.shortcuts import render
from worker.models import Worker
from login.models import Login
# Create your views here.
def postworker(request):
    if request.method=="POST":
        obj=Worker()
        obj.pin=request.POST.get('pin')
        obj.phone=request.POST.get('phone')
        obj.name=request.POST.get('wname')
        obj.gender=request.POST.get('gender')
        obj.email=request.POST.get('email')
        obj.district=request.POST.get('district')
        obj.category=request.POST.get('category')
        obj.place=request.POST.get('place')
        obj.save()
    return render(request,'worker/Worker.html')


def Viewworker(request):
    obj=Worker.objects.all()
    context={
        'o':obj
    }
    return render(request, 'worker/view_workers.html',context)
def Editprofile(request):
    obj=Worker.objects.all()
    context={
        'o':obj
    }
    return render(request,'worker/Edit_wprofile.html',context)
def WEdit(request,idd):
    ob = Worker.objects.get(w_id=idd)
    context = {
         'r': ob
     }
    if request.method == "POST":
        obj = Worker.objects.get(w_id=idd)
        obj.name = request.POST.get('wname')
        obj.place = request.POST.get('place')
        obj.district= request.POST.get('district')
        obj.pin=request.POST.get('pin')
        obj.phone=request.POST.get('phone')
        obj.email=request.POST.get('email')
        obj.gender=request.POST.get('gender')
        obj.category=request.POST.get('category')
        obj.save()
        return Editprofile(request)
    return render(request,'worker/WEdit.html',context)



from rest_framework.views import APIView,Response
from worker.serializers import android_serialiser

class reg(APIView):
    def post(self,request):
        obj=Worker()
        obj.pin = request.data['pin']
        obj.phone = request.data['phone']
        obj.name = request.data['name']
        obj.gender = request.data['gender']
        obj.email = request.data['email']
        obj.district = request.data['district']
        obj.category = request.data['category']
        obj.place = request.data['place']
        obj.save()
        ob=Login()
        ob.username=obj.name
        ob.password=obj.phone
        ob.u_id=obj.w_id
        ob.type='worker'
        ob.save()
        return HttpResponse('yes')


class profile(APIView):
    def post(self,request):
        obj=Worker.objects.filter(w_id=request.data['uid'])
        ser=android_serialiser(obj,many=True)
        return Response(ser.data)