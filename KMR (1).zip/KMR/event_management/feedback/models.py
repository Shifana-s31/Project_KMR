from django.db import models
from booking.models import Booking
from user.models import User
# Create your models here.
class Feedback(models.Model):
    feed_id = models.AutoField(primary_key=True)
    # book_id = models.IntegerField(blank=True, null=True)
    book=models.ForeignKey(Booking,on_delete=models.CASCADE)
    text = models.CharField(max_length=300)
    date = models.DateField()
    # u_id = models.IntegerField()
    u=models.ForeignKey(User,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'feedback'
