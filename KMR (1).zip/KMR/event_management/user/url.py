from django.conf.urls import url
from user import views

urlpatterns=[
    url('post_user/',views.postuser),
    url('view_user/',views.Viewuser),
    url('Edit_profile/',views.Editprofile),
    url('Edit/(?P<idd>\w+)',views.Edit)
]