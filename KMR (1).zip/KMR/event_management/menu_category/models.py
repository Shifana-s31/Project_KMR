from django.db import models

# Create your models here.
class MenuCategory(models.Model):
    cat_id = models.AutoField(primary_key=True)
    cat_name = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'menu_category'
