from django.conf.urls import url
from menu_category import views

urlpatterns=[
    url('post_menucategory/',views.postmenucategory),
    url('manage_categories/',views.managecategories),
    url('view_categories/',views.Viewcategories),
    url('deletemenu/(?P<idd>\w+)',views.deletemenu),
    url('editmenu/(?P<idd>\w+)',views.editcategory)
]