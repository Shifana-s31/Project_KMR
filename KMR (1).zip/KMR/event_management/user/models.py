from django.db import models

# Create your models here.
class User(models.Model):
    u_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    address = models.CharField(db_column='Address', max_length=60)  # Field name made lowercase.
    place = models.CharField(max_length=45)
    district = models.CharField(max_length=45)
    pin = models.IntegerField()
    phone = models.CharField(max_length=45)
    email = models.CharField(max_length=45)
    gender = models.CharField(max_length=10)
    password = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'user'

