from django.conf.urls import url
from event import views

urlpatterns=[
    url('post_event/',views.postevent),
    url('view_events/',views.Viewevents),
    url('view_schedulings/', views.viewschedulings),
    url('workervw/',views.worker_vw.as_view())
]