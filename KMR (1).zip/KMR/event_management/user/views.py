from django.shortcuts import render
from user.models import User
from login.models import Login
# Create your views here.
def postuser(request):
    if request.method=="POST":
        obj=User()
        obj.address=request.POST.get('Address')
        obj.district=request.POST.get('district')
        obj.email=request.POST.get('email')
        obj.gender=request.POST.get('gender')
        obj.name=request.POST.get('name')
        obj.phone=request.POST.get('phone')
        obj.pin=request.POST.get('pin')
        obj.place=request.POST.get('place')
        obj.password=request.POST.get('pass')
        obj.save()
        ob=Login()
        ob.username=obj.name
        ob.password=obj.password
        ob.u_id=obj.u_id
        ob.type='user'
        ob.save()
    return render(request, 'user/user.html', {'registered': True})
    return render(request, 'user/user.html')
    return render(request,'user/user.html')

def Viewuser(request):
    obj=User.objects.all()
    context={
        'o':obj
    }
    return render(request, 'user/view_user.html',context)

def Editprofile(request):
    ss=request.session['u_id']
    obj=User.objects.filter(u_id=ss)
    context={
        'o':obj
    }
    return render(request,'user/Edit_profile.html',context)

def Edit(request,idd):
    ob = User.objects.get(u_id=idd)
    context = {
        'r': ob
    }
    if request.method == "POST":
        obj = User.objects.get(u_id=idd)
        obj.name = request.POST.get('name')
        obj.address= request.POST.get('Address')
        obj.place = request.POST.get('place')
        obj.district= request.POST.get('district')
        obj.pin=request.POST.get('pin')
        obj.phone=request.POST.get('phone')
        obj.email=request.POST.get('email')
        obj.gender=request.POST.get('gender')
        obj.save()
        return Editprofile(request)
    return render(request,'user/Edit.html',context)
