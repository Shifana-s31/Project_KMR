from django.conf.urls import url
from worker import views

urlpatterns=[
    url('post_worker/',views.postworker),
    url('view_worker/',views.Viewworker),
    url('Edit_wprofile/',views.Editprofile),
    url('WEdit/(?P<idd>\w+)',views.WEdit),
    url('profile/',views.profile.as_view()),
    url('reg/',views.reg.as_view())
]