from django.conf.urls import url
from complaint import views

urlpatterns=[
    url('post_complaint/',views.postcomplaint),
    url('post_reply/(?P<idd>\w+)',views.postreply),
    url('view_complaint/',views.Viewcomplaints),
    url('view_replys/',views.Viewreplys)
]