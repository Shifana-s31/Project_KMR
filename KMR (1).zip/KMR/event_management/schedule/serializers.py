from rest_framework import serializers
from schedule.models import Schedule

class android_serializer(serializers.ModelSerializer):
    ename=serializers.CharField(source='event.event_name')
    wname=serializers.CharField(source='worker.name')
    class Meta:
        model=Schedule
        fields=['ename','schedule_id','wname','date','venue','location']