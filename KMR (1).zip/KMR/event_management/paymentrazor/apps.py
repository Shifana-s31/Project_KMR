from django.apps import AppConfig


class PaymentrazorConfig(AppConfig):
    name = 'paymentrazor'
