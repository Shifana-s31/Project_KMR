# from django.shortcuts import render
# from menu_items.models import MenuItems,Pay
# from django.core.files.storage import FileSystemStorage
# from menu_category.models import MenuCategory
# # Create your views here.
# def postmenuitems(request):
#     ob=MenuCategory.objects.all()
#     context={
#         'x':ob
#     }
#     if request.method=="POST":
#         obj=MenuItems()
#         obj.item_name=request.POST.get('name')
#         obj.description=request.POST.get('description')
#         obj.cat_id=request.POST.get('scat')
#         # obj.image=request.POST.get('image')
#         myfile=request.FILES['image']
#         fs=FileSystemStorage()
#         filename=fs.save(myfile.name,myfile)
#         obj.image=myfile.name
#         # obj.quantity=request.POST.get('Quantity')
#         obj.price=request.POST.get('Price')
#         obj.amount=request.POST.get('actualprice')
#         obj.save()
#     return render(request,'menu_items/menuitems.html',context)
#
#
# def Viewmenuitems(request):
#     obj=MenuItems.objects.all()
#     context={
#         'o':obj
#     }
#     return render(request, 'menu_items/View_menu items.html',context)
#
# def Managemenu(request):
#     obj=MenuItems.objects.all()
#     context={
#         'o':obj
#     }
#     return render(request, 'menu_items/manage_menu.html', context)
#
# def updatemenu(request,idd):
#     ob = MenuItems.objects.get(item_id=idd)
#     context = {
#         'r': ob
#     }
#     if request.method == "POST":
#         obj = MenuItems.objects.get(item_id=idd)
#         # obj.cat_id=request.POST.get('scat')
#         obj.item_name= request.POST.get('name')
#         obj.description=request.POST.get('description')
#         obj.price=request.POST.get('Price')
#         # obj.image= request.POST.get('image')
#         myfile=request.FILES['image']
#         fs=FileSystemStorage()
#         filename=fs.save(myfile.name,myfile)
#         obj.image=myfile.name
#         obj.amount=request.POST.get('actualamount')
#         # obj.quantity=request.POST.get('Quantity')
#         obj.save()
#         return Managemenu(request)
#     return render(request, 'menu_items/update_menu.html', context)
#
#
# def order(request):
#     obj=MenuItems.objects.all()
#     context={
#         'o':obj
#     }
#     return render(request, 'menu_items/order.html',context)
#
# import datetime
#
# from booking.models import Booking
#
# def pay(request,idd):
#     ss=request.session['u_id']
#     print(ss)
#     print(idd)
#     ab=MenuItems.objects.get(item_id=idd)
#     bo = Booking.objects.filter(u_id=ss)
#     context={
#         'a':ab,
#         'b': bo
#     }
#     if request.method=="POST":
#         am=request.POST.get('price')
#         c=request.POST.get('qty')
#         print(am)
#         print(type(am))
#         print(c)
#         print(type(c))
#
#         obj=Pay()
#         # c=Booking.objects.filter(u_id=ss).first()
#         obj.book_id= request.POST.get('booking')
#         obj.item_id=idd
#         obj.u_id=ss
#         obj.count = request.POST.get('qty')
#         obj.amount=int(am)*int(c)
#         obj.date=datetime.datetime.today()
#         obj.time=datetime.datetime.now()
#         obj.status='paid'
#         obj.save()
#     return render(request,'menu_items/pay.html',context)
#
#
#
# def view_order(request):
#     obj=Pay.objects.all()
#     context={
#         'x':obj
#     }
#     return render(request,'menu_items/view_order.html',context)


from django.shortcuts import render
from menu_items.models import MenuItems,Pay
from django.core.files.storage import FileSystemStorage
from menu_category.models import MenuCategory
from select_services.models import SelectServices
# Create your views here.
def postmenuitems(request):
    ob=MenuCategory.objects.all()
    context={
        'x':ob
    }
    if request.method=="POST":
        obj=MenuItems()
        obj.item_name=request.POST.get('name')
        obj.description=request.POST.get('description')
        obj.cat_id=request.POST.get('scat')
        # obj.image=request.POST.get('image')
        myfile=request.FILES['image']
        fs=FileSystemStorage()
        filename=fs.save(myfile.name,myfile)
        obj.image=myfile.name
        # obj.quantity=request.POST.get('Quantity')
        obj.price=request.POST.get('Price')
        obj.amount=request.POST.get('actualprice')
        obj.save()
    return render(request,'menu_items/menuitems.html',context)


def Viewmenuitems(request):
    obj=MenuItems.objects.all()
    context={
        'o':obj
    }
    return render(request, 'menu_items/View_menu items.html',context)

def Managemenu(request):
    obj=MenuItems.objects.all()
    context={
        'o':obj
    }
    return render(request, 'menu_items/manage_menu.html', context)

def updatemenu(request,idd):
    ob = MenuItems.objects.get(item_id=idd)
    context = {
        'r': ob
    }
    if request.method == "POST":
        obj = MenuItems.objects.get(item_id=idd)
        # obj.cat_id=request.POST.get('scat')
        obj.item_name= request.POST.get('name')
        obj.description=request.POST.get('description')
        obj.price=request.POST.get('Price')
        # obj.image= request.POST.get('image')
        myfile=request.FILES['image']
        fs=FileSystemStorage()
        filename=fs.save(myfile.name,myfile)
        obj.image=myfile.name
        obj.amount=request.POST.get('actualamount')
        # obj.quantity=request.POST.get('Quantity')
        obj.save()
        return Managemenu(request)
    return render(request, 'menu_items/update_menu.html', context)


def order(request):
    obj=MenuItems.objects.all()
    context={
        'o':obj
    }
    return render(request, 'menu_items/order.html',context)

import datetime

from booking.models import Booking

def pay(request,idd):
    ss=request.session['u_id']
    print(ss)
    print(idd)
    ab=MenuItems.objects.get(item_id=idd)
    bo = Booking.objects.filter(u_id=ss)
    context={
        'a':ab,
        'b': bo
    }
    if request.method=="POST":
        am=request.POST.get('price')
        c=request.POST.get('qty')
        print(am)
        print(type(am))
        print(c)
        print(type(c))

        obj=Pay()
        # c=Booking.objects.filter(u_id=ss).first()
        obj.book_id= request.POST.get('booking')
        obj.item_id=idd
        obj.u_id=ss
        obj.count = request.POST.get('qty')
        obj.amount=int(am)*int(c)
        obj.date=datetime.datetime.today()
        obj.time=datetime.datetime.now()
        obj.status='paid'
        obj.save()
    return render(request,'menu_items/pay.html',context)



# def view_order(request):
#     obj=Pay.objects.all()
#     obb=SelectServices.objects.all()
#     context={
#         'x':obj,
#         'a':obb
#     }
#     return render(request,'menu_items/view_order.html',context)

def view_order(request):
    obb = []
    for pay in Pay.objects.all():
        services = SelectServices.objects.filter(u_id=pay.u_id)
        for s in services:
            obb.append({'pay': pay, 'service': s})
    return render(request, 'menu_items/view_order.html', {'obj': obb})

