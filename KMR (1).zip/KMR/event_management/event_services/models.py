from django.db import models

# Create your models here.

class EventServices(models.Model):
    service_id = models.AutoField(primary_key=True)
    service_name = models.CharField(max_length=45)
    description = models.CharField(max_length=600)
    price = models.IntegerField()
    image = models.CharField(max_length=226)
    # quantity = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'event_services'
