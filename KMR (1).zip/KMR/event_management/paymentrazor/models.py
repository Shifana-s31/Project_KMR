from django.db import models
from user.models import User
from select_services.models import SelectServices
from select_menu.models import SelectMenu
from event_services.models import EventServices
from menu_items.models import MenuItems

# Create your models here.
class Viewselectedmenu(models.Model):
    viewselectedmenu_id = models.AutoField(primary_key=True)
    # item_id = models.IntegerField()
    item = models.ForeignKey(MenuItems, on_delete=models.CASCADE)
    count = models.IntegerField()
    price = models.CharField(max_length=45)
    subtotal = models.CharField(max_length=45)
    # u_id = models.CharField(max_length=45)
    u = models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.CharField(max_length=45)
    time = models.CharField(max_length=45)
    booking_id = models.IntegerField()


    class Meta:
        managed = False
        db_table = 'viewselectedmenu'


class Viewselectedservice(models.Model):
    viewselectedservice_id = models.AutoField(primary_key=True)
    price = models.CharField(max_length=45)
    count = models.IntegerField()
    subtotal = models.CharField(max_length=45)
    # u_id = models.IntegerField()
    u = models.ForeignKey(User, on_delete=models.CASCADE)
    # service_id = models.IntegerField()
    service = models.ForeignKey(EventServices, on_delete=models.CASCADE)
    date = models.CharField(max_length=45)
    time = models.CharField(max_length=45)
    booking_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'viewselectedservice'
