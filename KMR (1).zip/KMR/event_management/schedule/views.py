from django.shortcuts import render
from schedule.models import Schedule
from worker.models import Worker
from event.models import Event

# Create your views here.
def schedule(request):
    ob = Worker.objects.all()
    oc = Event.objects.all()
    context = {
         'w': ob,
        'e': oc
    }
    if request.method=="POST":
        obj=Schedule()
        obj.event_id=request.POST.get('event')
        obj.worker_id=1
        obj.venue=request.POST.get('venu')
        obj.location=request.POST.get('location')
        obj.date=request.POST.get('date')
        obj.save()
    return render(request,'schedule/schedule.html',context)




def Viewmenuitems(request):
    obj=Schedule.objects.all()
    context={
        'o':obj
    }
    return render(request, 'schedule/schedulings_view.html',context)
from rest_framework.views import APIView,Response
from schedule.serializers import android_serializer
from django.http import HttpResponse

class viewww(APIView):
    def get(self,request):
        obj=Schedule.objects.all()
        ser=android_serializer(obj,many=True)
        return Response(ser.data)