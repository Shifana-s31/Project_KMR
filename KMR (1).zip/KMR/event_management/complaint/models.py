from django.db import models
from user.models import User
from booking.models import Booking
# Create your models here.
class Complaint(models.Model):
    comp_id = models.AutoField(primary_key=True)
    # book_id = models.IntegerField(blank=True, null=True)
    book=models.ForeignKey(Booking,on_delete=models.CASCADE)
    text = models.CharField(max_length=250)
    # u_id = models.IntegerField(blank=True, null=True)
    u=models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.DateField()
    reply = models.CharField(max_length=150)
    category = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'complaint'


