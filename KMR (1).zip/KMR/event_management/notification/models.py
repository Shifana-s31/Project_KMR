from django.db import models
from booking.models import Booking
from user.models import User

# Create your models here.
class Notification(models.Model):
    not_id = models.AutoField(primary_key=True)
    # book_id = models.IntegerField(blank=True, null=True)
    book=models.ForeignKey(Booking,on_delete=models.CASCADE)
    # u_id = models.IntegerField(blank=True, null=True)
    u=models.ForeignKey(User,on_delete=models.CASCADE)
    message = models.CharField(max_length=300)
    date = models.DateField(blank=True, null=True)
    type = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'notification'

