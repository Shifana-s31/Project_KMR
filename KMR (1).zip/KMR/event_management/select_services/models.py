from django.db import models
from event_services.models import EventServices
from booking.models import Booking
# Create your models here.
class SelectServices(models.Model):
    select_id = models.AutoField(primary_key=True)
    # service_id = models.IntegerField()
    service=models.ForeignKey(EventServices,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.IntegerField()
    u_id = models.IntegerField()
    # booking_id = models.IntegerField()
    booking = models.ForeignKey(Booking,on_delete=models.CASCADE)
    class Meta:
        managed = False
        db_table = 'select_services'





