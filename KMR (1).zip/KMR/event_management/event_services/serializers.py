from rest_framework import serializers
from event_services.models import EventServices

class android_serialiser(serializers.ModelSerializer):
    class Meta:
        model=EventServices
        fields='__all__'