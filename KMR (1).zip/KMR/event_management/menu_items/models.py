from django.db import models
from menu_category.models import MenuCategory
from user.models import User
# Create your models here.
class MenuItems(models.Model):
    item_id = models.AutoField(primary_key=True)
    # cat_id = models.IntegerField(blank=True, null=True)
    cat=models.ForeignKey(MenuCategory,on_delete=models.CASCADE)
    item_name = models.CharField(max_length=45)
    description = models.CharField(max_length=150)
    price = models.IntegerField()
    # quantity = models.IntegerField()
    image = models.CharField(max_length=229)
    amount = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'menu_items'


class Pay(models.Model):
    pay_id = models.AutoField(primary_key=True)
    # item_id = models.IntegerField()
    item=models.ForeignKey(MenuItems,on_delete=models.CASCADE)
    amount = models.CharField(max_length=45)
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(max_length=45)
    # u_id = models.IntegerField()
    u=models.ForeignKey(User,on_delete=models.CASCADE)
    count = models.IntegerField()
    book_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'pay'
