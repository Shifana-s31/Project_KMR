from django.shortcuts import render
from event.models import Event

# Create your views here.
def postevent(request):
    if request.method=="POST":
        obj=Event()
        obj.event_name=request.POST.get('Event')
        obj.details=request.POST.get('event')
        obj.save()
    return render(request,'event/Event.html')





def Viewevents(request):
    obj=Event.objects.all()
    context={
        'o':obj
    }
    return render(request, 'event/view_events.html',context)

def viewschedulings(request):
    obj=Event.objects.all()
    context={
        'o':obj
    }
    return render(request, 'event/view_schedulings.html', context)


from rest_framework.views import APIView,Response
from event.serializers import android_serialiser


class worker_vw(APIView):
    def get(self,request):
        obj=Event.objects.all()
        ser=android_serialiser(obj,many=True)
        return Response(ser.data)