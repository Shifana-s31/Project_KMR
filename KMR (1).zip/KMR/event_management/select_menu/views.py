from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from select_menu.models import SelectMenu
from menu_items.models import MenuItems
from booking.models import Booking
# Create your views here.
def Selectmenu(request,idd):
    ss=request.session['u_id']
    print(idd)
    ab=MenuItems.objects.get(item_id=idd)
    bo=Booking.objects.filter(u_id=ss)
    context={
        'a':ab,
        'b':bo
    }
    if request.method=="POST":
        obj=SelectMenu()
        obj.item_id=idd
        obj.booking_id=request.POST.get('booking')
        obj.u_id=ss
        obj.quantity=request.POST.get('Quantity')
        obj.price=int(ab.price)*int(obj.quantity)
        obj.save()
    return render(request,'select_menu/select.html',context)


