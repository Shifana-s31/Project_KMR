from django.db import models
from menu_items.models import MenuItems
from booking.models import Booking
# Create your models here.
class SelectMenu(models.Model):
    menu_id = models.AutoField(primary_key=True)
    # item_id = models.IntegerField()
    item=models.ForeignKey(MenuItems,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.CharField(max_length=45)
    u_id = models.IntegerField()
    # booking_id = models.IntegerField()
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'select_menu'
