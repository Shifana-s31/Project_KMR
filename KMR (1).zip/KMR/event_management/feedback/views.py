from django.shortcuts import render
from feedback.models import Feedback
import datetime
# Create your views here.
def postfeedback(request):
    ss=request.session['u_id']
    if request.method=="POST":
        obj=Feedback()
        obj.book_id=1
        obj.u_id=ss
        obj.text=request.POST.get('complaint')
        obj.date=datetime.datetime.today()
        obj.save()
    return render(request,'feedback/feedback.html')


def Viewfeedbacks(request):
    obj=Feedback.objects.all()
    context={
        'o':obj
    }
    return render(request, 'feedback/view_feedbacks.html',context)
