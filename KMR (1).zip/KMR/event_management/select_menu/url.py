from django.conf.urls import url
from select_menu import views

urlpatterns=[
             url('select_menu/(?P<idd>\w+)',views.Selectmenu)
]