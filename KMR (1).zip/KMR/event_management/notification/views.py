from django.shortcuts import render
from notification.models import Notification
import datetime
from user.models import User

# Create your views here.
def postnotification(request):
    if request.method=="POST":
        obj=Notification()
        obj.book_id=1
        obj.message=request.POST.get('complaint')
        obj.date=datetime.datetime.today()
        obj.type='worker'
        obj.save()
    return render(request,'notification/Notify.html')

def pp(request):
    ob=User.objects.all()
    context={
        'x':ob
    }
    if request.method=="POST":
        obj=Notification()
        obj.book_id=1
        obj.u_id=request.POST.get('uname')
        obj.message=request.POST.get('complaint')
        obj.date=datetime.datetime.today()
        obj.type='user'
        obj.save()
    return render(request,'notification/n.html',context)

def Viewnotification(request):
    ss = request.session['u_id']
    obj=Notification.objects.filter(u_id=ss,type='user')
    context={
        'o':obj
    }
    return render(request, 'notification/view_notify.html',context)

from rest_framework.views import APIView,Response
from notification.serializers import android_serialiser

class noti(APIView):
    def get(self,request):
        obj=Notification.objects.filter(type='worker')
        ser=android_serialiser(obj,many=True)
        return Response(ser.data)