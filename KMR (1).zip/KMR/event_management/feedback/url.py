from django.conf.urls import url
from feedback import views

urlpatterns=[
    url('post_feedback/',views.postfeedback),
    url('view_feedbacks/',views.Viewfeedbacks)
]