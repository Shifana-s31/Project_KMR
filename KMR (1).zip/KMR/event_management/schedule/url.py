from django.conf.urls import url
from schedule import views
from django.urls import path

urlpatterns=[
    url('schedule/',views.schedule),
    # url('calc/', views.calculate_total_payment_view, name='calculate_total_payment'),
    url('vvvv/',views.viewww.as_view())

]