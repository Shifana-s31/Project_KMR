from django.conf.urls import url
from menu_items import views

urlpatterns=[
    url('post_menuitems/',views.postmenuitems),
    url('view_menuitems/',views.Viewmenuitems),
    url('update_menu/(?P<idd>\w+)',views.updatemenu),
    url('manage_menu/',views.Managemenu),
    url('order/',views.order),
    url('pay/(?P<idd>\w+)',views.pay),
    url('aaaa/',views.view_order)
]