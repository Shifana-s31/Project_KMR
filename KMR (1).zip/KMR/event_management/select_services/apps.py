from django.apps import AppConfig


class SelectServicesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'select_services'
