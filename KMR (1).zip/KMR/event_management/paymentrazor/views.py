from django.shortcuts import render
from select_menu.models import SelectMenu
from select_services.models import SelectServices
import datetime
# Create your views here.
# rzp_test_Ey8ivDWGODPlAZ == api
# ttmCr5Cy7mQYI2Eck7W6UD3u == sec

# from django.shortcuts import render
# from order.models import Order
# from payment.models import Payment
# from django.conf import settings
# import datetime
# import razorpay
#
# def payment_form(request,idd):
#     uid=request.session["u_id"]
#     razorpay_key = 'rzp_test_Ey8ivDWGODPlAZ'
#     ob=Order.objects.get(o_id=idd)
#     qty=int(ob.quantity)
#     # amount=ob.p.p_name
#     amount = (int(ob.p.p_price)*100)*qty
#     context={
#         'razorpay_key': razorpay_key,
#         'amt':str(amount)
#     }
#     obj=Payment()
#     obj.o_id=idd
#     obj.u_id=uid
#     obj.status='pending'
#     obj.amount=amount
#     obj.date_time=datetime.datetime.now()
#     # obj.owner_id=ob.route.owner_id
#     obj.save()
#     request.session['payid']=str(obj.payment_id)
#     return render(request, 'paymentrazor.html', context)
#
# from django.http import JsonResponse
# def update_payment(request):
#
#     ob=Payment.objects.get(payment_id=request.session['payid'])
#     ob.status='paid'
#     ob.save()
#     obj = Order.objects.get(o_id=ob.o_id)
#     obj.status='paid'
#     obj.save()
#     msg = {
#
#         'al': 'Payment completed Successfully',
#     }
#     return JsonResponse(msg)










# Create your views here.
# rzp_test_Ey8ivDWGODPlAZ == api
# ttmCr5Cy7mQYI2Eck7W6UD3u == sec

from django.shortcuts import render
# from order.models import Order
from payment.models import Payment
from booking.models import Booking
from django.conf import settings
import datetime
import razorpay

# def payment_form(request,idd):
#     uid=request.session["u_id"]
#     razorpay_key = 'rzp_test_Ey8ivDWGODPlAZ'
#     ob=Booking.objects.get(o_id=idd)
#     qty=int(ob.quantity)
#     # amount=ob.p.p_name
#     amount = (int(ob.p.p_price)*100)*qty
#     context={
#         'razorpay_key': razorpay_key,
#         'amt':str(amount)
#     }
#     obj=Payment()
#     obj.book_id=idd
#     obj.u_id=uid
#     obj.status='pending'
#     # obj.amount=amount
#     obj.date=datetime.datetime.now()
#     # obj.owner_id=ob.route.owner_id
#     obj.save()
#     request.session['payid']=str(obj.payment_id)
#     return render(request, 'paymentrazor1.html', context)
#
# from django.http import JsonResponse
# def update_payment(request):
#
#     ob=Payment.objects.get(payment_id=request.session['payid'])
#     ob.status='paid'
#     ob.save()
#     obj = Order.objects.get(o_id=ob.o_id)
#     obj.status='paid'
#     obj.save()
#     msg = {
#
#         'al': 'Payment completed Successfully',
#     }
#     return JsonResponse(msg)


from django.shortcuts import render
from paymentrazor.models import Viewselectedmenu,Viewselectedservice
import datetime



def payment_form(request, idd):  # idd = total amount from cart
    uid = request.session.get("u_id")  # Get user ID from session
    razorpay_key = 'rzp_test_Ey8ivDWGODPlAZ'  # Your Razorpay key

    amount = int(idd) * 100 *(25/100) # Convert total amount to cents for Razorpay

    # Context data for Razorpay payment page
    context = {
        'razorpay_key': razorpay_key,
        'amt': str(amount),
    }

    se=SelectMenu.objects.filter(u_id=uid)
    for s in se:
        vs=Viewselectedmenu()
        vs.u_id=uid
        vs.booking_id=s.booking_id
        vs.price=s.item.price
        vs.time=datetime.datetime.now()
        vs.date=datetime.datetime.today()
        vs.count=s.quantity
        vs.item_id=s.item_id
        vs.subtotal=int(s.quantity)*int(s.item.price)
        vs.save()

    ss = SelectServices.objects.filter(u_id=uid)
    for c in ss:
        vv = Viewselectedservice()
        vv.u_id = uid
        vv.price = c.service.price
        vv.booking_id = c.booking_id
        vv.time = datetime.datetime.now()
        vv.date = datetime.datetime.today()
        vv.count = c.quantity
        vv.service_id = c.service_id
        vv.subtotal = int(c.quantity) * int(c.service.price)
        vv.save()


    # Save payment details in the database
    obj = Payment()
    obj.u_id = uid
    obj.status = 'paid'
    obj.amount = amount/100  # Store total amount in the database
    obj.date = datetime.datetime.now()
    obj.save()

    request.session['payid'] = str(obj.payment_id)  # Save payment ID in session

    return render(request, 'paymentrazor1.html', context)






def payment_formsingle(request, idd):  # idd = total amount from cart
    uid = request.session.get("u_id")  # Get user ID from session
    razorpay_key = 'rzp_test_Ey8ivDWGODPlAZ'  # Your Razorpay key

    amount = int(idd) * 100 *(25/100) # Convert total amount to cents for Razorpay

    # Context data for Razorpay payment page
    context = {
        'razorpay_key': razorpay_key,
        'amt': str(amount),
    }

    # se=SelectMenu.objects.filter(u_id=uid)
    # for s in se:
    #     vs=Viewselectedmenu()
    #     vs.u_id=uid
    #     vs.price=s.item.price
    #     vs.time=datetime.datetime.now()
    #     vs.date=datetime.datetime.today()
    #     vs.count=s.quantity
    #     vs.item_id=s.item_id
    #     vs.subtotal=int(s.quantity)*int(s.item.price)
    #     vs.save()

    # ss = SelectServices.objects.filter(u_id=uid)
    # for c in ss:
    #     vv = Viewselectedservice()
    #     vv.u_id = uid
    #     vv.price = c.service.price
    #     vv.time = datetime.datetime.now()
    #     vv.date = datetime.datetime.today()
    #     vv.count = c.quantity
    #     vv.service_id = c.service_id
    #     vv.subtotal = int(c.quantity) * int(c.service.price)
    #     vv.save()


    # Save payment details in the database
    obj = Payment()
    obj.u_id = uid
    # obj.book_id =
    obj.status = 'paid'
    obj.amount = amount/100  # Store total amount in the database
    obj.date = datetime.datetime.now()
    obj.save()

    request.session['payid'] = str(obj.payment_id)  # Save payment ID in session

    return render(request, 'paymentrazor2.html', context)









