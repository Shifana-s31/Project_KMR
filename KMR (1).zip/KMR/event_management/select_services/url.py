from django.conf.urls import url
from select_services import views

urlpatterns=[
    url('select_services/(?P<idd>\w+)',views.Selectservices),
    url('view_cart/', views.view_user_cart, name='view_user_cart'),

    url('view_m_s_pay/',views.viewmandspay),
    url('view_cartsingle/', views.view_user_cartsingle),



]