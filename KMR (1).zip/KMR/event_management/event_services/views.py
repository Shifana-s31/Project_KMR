from django.shortcuts import render
from event_services.models import EventServices
from django.core.files.storage import FileSystemStorage
# Create your views here.
def posteventservices(request):
    if request.method=='POST':
        obj=EventServices()
        obj.description=request.POST.get('description')
        obj.price=request.POST.get('Price')
        # obj.quantity=request.POST.get('quantity')
        obj.service_name=request.POST.get('name')
        # obj.image=request.POST.get('Quantity')
        myfile=request.FILES['img']
        fs=FileSystemStorage()
        filename=fs.save(myfile.name,myfile)
        obj.image=myfile.name
        obj.save()
    return render(request,'event_services/eventservices.html')


def Viewandselectservices(request):
    obj=EventServices.objects.all()
    context={
        'o':obj
    }
    return render(request, 'event_services/view and select_services.html',context)


from rest_framework.views import APIView,Response
from event_services.serializers import android_serialiser


class view_ev_ser(APIView):
    def get(self,request):
        obj=EventServices.objects.all()
        ser=android_serialiser(obj,many=True)
        return Response(ser.data)
