from django.conf.urls import url
from event_services import views

urlpatterns=[
    url('post_eventservices/',views.posteventservices),
    url('view_select_services/',views.Viewandselectservices),
    url('vw/',views.view_ev_ser.as_view())
]