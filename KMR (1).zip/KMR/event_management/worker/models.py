from django.db import models

# Create your models here.

class Worker(models.Model):
    w_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    place = models.CharField(max_length=30)
    district = models.CharField(max_length=45)
    pin = models.CharField(max_length=10)
    gender = models.CharField(max_length=10)
    phone = models.CharField(max_length=10)
    email = models.CharField(max_length=40)
    category = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'worker'





