from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from select_menu.models import SelectMenu
from select_services.models import SelectServices
from payment.models import Payment


def Viewpaymentstatus(request):
    ss=request.session['u_id']
    obj=Payment.objects.filter(u_id=ss)
    context={
        'a':obj
    }
    return render(request, 'payment/view payment_status_admin.html',context)


def Viewpaymentstatusadmin(request):
    obj=Payment.objects.all()
    context={
        'a':obj
    }
    return render(request, 'payment/view payment_status.html',context)








from django.db.models.functions import Cast
from django.db.models import FloatField, F, Sum

# def calculate_total_payment(u_id):
#     menu_total = SelectMenu.objects.filter(u_id=u_id).annotate(
#         price_num=Cast('price', FloatField())
#     ).aggregate(
#         total=Sum(F('quantity') * F('price_num'), output_field=FloatField())
#     )['total'] or 0
#
#     services_total = SelectServices.objects.filter(u_id=u_id).aggregate(
#         total=Sum(F('quantity') * F('price'), output_field=FloatField())
#     )['total'] or 0
#
#     grand_total = menu_total + services_total
#
#     return grand_total


# def calculate_total_payment_view(request):
#     u_id = request.GET.get('u_id')
#
#     if not u_id:
#         return JsonResponse({'error': 'Please provide u_id in query string like /calc/?u_id=5'}, status=400)
#
#     if not u_id.isdigit():
#         return JsonResponse({'error': 'u_id must be a number'}, status=400)
#
#     total = calculate_total_payment(int(u_id))
#     return JsonResponse({'total': total})


def calculate_total_payment(u_id):
    menu_total = SelectMenu.objects.filter(u_id=u_id).annotate(
        price_num=Cast('price', FloatField())
    ).aggregate(
        total=Sum(F('quantity') * F('price_num'), output_field=FloatField())
    )['total'] or 0

    services_total = SelectServices.objects.filter(u_id=u_id).aggregate(
        total=Sum(F('quantity') * F('price'), output_field=FloatField())
    )['total'] or 0

    return menu_total + services_total


def calculate_total_payment_view(request, u_id):
    total = calculate_total_payment(u_id)
    return render(request, 'payment/payment_summary.html', {'total': total, 'u_id': u_id})