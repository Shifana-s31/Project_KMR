from django.shortcuts import render
from complaint.models import Complaint
import datetime
from booking.models import Booking
# Create your views here.
def postcomplaint(request):
    ob=Booking.objects.all()
    context={
        'x':ob
    }
    ss = request.session['u_id']
    if request.method=="POST":
        obj=Complaint()
        obj.u_id=ss
        obj.book_id=request.POST.get('bookid')
        obj.date=datetime.datetime.today()
        obj.text=request.POST.get('complaint')
        obj.category=request.POST.get('category')
        obj.save()
    return render(request,'complaint/Complaint.html',context)

def postreply(request,idd):
    if request.method=="POST":
        obj=Complaint.objects.get(comp_id=idd)
        obj.reply=request.POST.get('reply')
        obj.save()
        return Viewcomplaints(request)
    return render(request, 'complaint/ComplaintRply.html')

def Viewcomplaints(request):
    obj=Complaint.objects.all()
    context={
        'o':obj
    }
    return render(request, 'complaint/view_complaints.html',context)

def Viewreplys(request):
    ss = request.session['u_id']
    obj=Complaint.objects.filter(u_id=ss)
    context={
        'o':obj
    }
    return render(request, 'complaint/view_replys.html',context)

