
from django.shortcuts import render, redirect
from select_services.models import SelectServices
from select_menu.models import SelectMenu
from event_services.models import EventServices
from menu_items.models import Pay
from booking.models import Booking
# Create your views here.
def Selectservices(request,idd):
    ss = request.session['u_id']
    obj=EventServices.objects.get(service_id=idd)
    bo = Booking.objects.filter(u_id=ss)
    context={
        'a':obj,
        'b': bo
    }
    if request.method=="POST":
        obj=SelectServices()
        obj.service_id=idd
        obj.booking_id=request.POST.get('booking')
        obj.u_id=ss
        obj.price=request.POST.get('price')
        obj.quantity=1
        obj.save()
    return render(request,'select_services/service_selection.html',context)


# def view_user_cart(request):
#     # Check session for u_id
#     ss = request.session['u_id']
#
#     if not ss:
#         return redirect('/login/login/')  # Redirect if u_id is not in session (e.g., not logged in)
#
#     # Fetch selected menu items
#     menu_items = SelectMenu.objects.filter(u_id=ss)
#
#     # Fetch selected services
#     services = SelectServices.objects.filter(u_id=ss)
#
#     context = {
#         'menu_items': menu_items,
#         'services': services,
#     }
#
#     return render(request, 'select_services/user_cart.html', context)


def view_user_cart(request):
    u_id = request.session.get('u_id')
    print(u_id)
    if not u_id:
        return redirect('login')  # Or show message for unauthorized access



    menu_items = SelectMenu.objects.filter(u_id=u_id)
    services = SelectServices.objects.filter(u_id=u_id)
    print(menu_items)
    print(services)

    # Prepare menu item subtotals
    menu_data = []
    total_menu = 0
    for item in menu_items:
        print(item.item.price)
        price = float(item.item.price)
        print(price)
        subtotal = price * item.quantity
        total_menu += subtotal
        menu_data.append({
            'name': item.item.item_name,
            'quantity': item.quantity,
            'price': price,
            'subtotal': subtotal,
            'booking_id': item.booking_id
        })

    # Prepare service subtotals
    service_data = []
    total_services = 0
    for svc in services:
        subtotal = svc.price * svc.quantity
        total_services += subtotal
        service_data.append({
            'name': svc.service.service_name,
            'quantity': svc.quantity,
            'price': svc.price,
            'subtotal': subtotal,
            'booking_id': svc.booking_id
        })

    grand_total = total_menu + total_services

    context = {
        'menu_data': menu_data,
        'service_data': service_data,
        'total': grand_total,
        'u_id': u_id,
    }

    return render(request, 'select_services/user_cart.html', context)

from paymentrazor.models import Viewselectedservice,Viewselectedmenu



def viewmandspay(request):
    obj = Viewselectedservice.objects.all()
    ob = Viewselectedmenu.objects.all()
    context = {
        's': obj,
        'm':ob
    }
    return render(request,'select_services/view_m_and_s_payment.html',context)



def view_user_cartsingle(request):
    u_id = request.session.get('u_id')
    print(u_id)
    if not u_id:
        return redirect('login')  # Or show message for unauthorized access



    menu_items = Pay.objects.filter(u_id=u_id)
    services = SelectServices.objects.filter(u_id=u_id)
    print(menu_items)
    print(services)

    # Prepare menu item subtotals
    menu_data = []
    total_menu = 0
    for item in menu_items:
        print(item.item.price)
        price = float(item.amount)
        print(price)
        # subtotal = price * item.quantity
        total_menu += price
        menu_data.append({
            'name': item.item.item_name,
            'quantity': item.count,
            'price': price,
            # 'subtotal': subtotal
            'book_id': item.book_id
        })

    # Prepare service subtotals
    service_data = []
    total_services = 0
    for svc in services:
        subtotal = svc.price * svc.quantity
        total_services += subtotal
        service_data.append({
            'name': svc.service.service_name,
            'quantity': svc.quantity,
            'price': svc.price,
            'subtotal': subtotal,
            'booking_id': svc.booking_id
        })

    grand_total = total_menu + total_services

    context = {
        'menu_data': menu_data,
        'service_data': service_data,
        'total': grand_total,
        'u_id': u_id,
    }

    return render(request, 'select_services/user_cart_sinlge.html', context)



