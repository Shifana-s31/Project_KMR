from django.db import models
from user.models import User
from event.models import Event
from event_services.models import EventServices
# from select_menu.models import SelectMenu

# Create your models here.
class Booking(models.Model):
    book_id = models.AutoField(primary_key=True)
    # u_id = models.IntegerField()
    u=models.ForeignKey(User,on_delete=models.CASCADE)
    # event_ = models.IntegerField()
    event=models.ForeignKey(Event,on_delete=models.CASCADE)
    book_date = models.DateField()
    book_date_time = models.CharField(max_length=45)
    venue = models.CharField(max_length=250)
    count = models.IntegerField()
    no_of_days = models.IntegerField(db_column='no of days')  # Field renamed to remove unsuitable characters.
    # adv_amount = models.IntegerField()
    # service_id = models.IntegerField()
    service=models.ForeignKey(EventServices,on_delete=models.CASCADE)
    menu_id = models.IntegerField()
    # menu=models.ForeignKey(SelectMenu,on_delete=models.CASCADE)
    event_date = models.DateField()
    total_amount = models.IntegerField()
    district = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'booking'


class BookingWorker(models.Model):
    bwork_id = models.AutoField(primary_key=True)
    w_id = models.IntegerField()
    work = models.CharField(max_length=60)
    date = models.DateField()
    time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'booking_worker'


