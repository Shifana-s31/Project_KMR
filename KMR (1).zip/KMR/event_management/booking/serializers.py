from rest_framework import serializers
from booking.models import BookingWorker

class android_serialiser(serializers.ModelSerializer):
    class Meta:
        model=BookingWorker
        fields='__all__'