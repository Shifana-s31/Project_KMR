from django.shortcuts import render
from menu_category.models import MenuCategory
# Create your views here.
def postmenucategory(request):
    if request.method=="POST":
        obj=MenuCategory()
        obj.cat_name=request.POST.get('cat')
        obj.save()
    return render(request,'menu_category/category.html')


def managecategories(request):
    obj=MenuCategory.objects.all()
    context={
        'o':obj
    }
    return render(request, 'menu_category/manage_categories.html',context)

def Viewcategories(request):
    obj=MenuCategory.objects.all()
    context={
        'o':obj
    }
    return render(request, 'menu_category/view_categories.html',context)
def updatecategory(request):
    obj=MenuCategory.objects.all()
    context={
        'o':obj
    }
    return render(request,'menu_category/Update_categories.html',context)
def deletemenu(request,idd):
    obj=MenuCategory.objects.get(cat_id=idd)
    obj.delete()
    return managecategories(request)
def editcategory(request,idd):
    ob=MenuCategory.objects.get(cat_id=idd)
    context={
        'r':ob
    }
    if request.method=="POST":
        obj=MenuCategory.objects.get(cat_id=idd)
        obj.cat_name=request.POST.get('cat')
        obj.save()
        return managecategories(request)
    return render(request,'menu_category/Update_categories.html',context)

