from django.db import models
from worker.models import Worker
from event.models import Event

# Create your models here.
class Schedule(models.Model):
    schedule_id = models.AutoField(primary_key=True)
    # worker_id = models.IntegerField()
    worker = models.ForeignKey(Worker,on_delete=models.CASCADE)
    date = models.DateField()
    venue = models.CharField(max_length=225)
    location = models.CharField(max_length=45)
    # event_id = models.IntegerField()
    event = models.ForeignKey(Event,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'schedule'
