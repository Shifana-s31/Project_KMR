from django.http import HttpResponse
from django.shortcuts import render
from booking.models import Booking
from event.models import Event
import datetime
# Create your views here.
def postbooking(request):
    ob=Event.objects.all()
    context={
        'x':ob
    }
    ss = request.session['u_id']
    if request.method=="POST":
        obj=Booking()
        obj.event_id=request.POST.get('ename')
        obj.menu_id=1
        obj.service_id=1
        obj.u_id=ss
        # obj.adv_amount=request.POST.get('phone')
        # obj.total_amount= request.POST.get('amount')
        obj.book_date=datetime.datetime.today()
        obj.book_date_time=datetime.datetime.now()
        obj.count=request.POST.get('count')
        obj.no_of_days=request.POST.get('pin')
        obj.district= request.POST.get('district')
        obj.venue=request.POST.get('place')
        obj.event_date=request.POST.get('datetime')
        obj.save()
    return render(request, 'booking/booking.html',context)


def viewbooking(request):
    obj=Booking.objects.all()
    context={
        'o':obj
    }
    return render(request, 'booking/view_bookings.html',context)



from rest_framework.views import APIView,Response
from booking.serializers import android_serialiser
from booking.models import BookingWorker



class book_worker(APIView):
    def post(self,request):
        obj=BookingWorker()
        obj.w_id=request.data['u_id']
        obj.work=request.data['work']
        obj.date=datetime.datetime.today()
        obj.time=datetime.datetime.now()
        obj.save()
        return HttpResponse('yes')


from django.shortcuts import render
from django.db.models.functions import TruncMonth
from django.db.models import Count, Sum
from .models import Booking

def monthly_report(request):
    report_data = (
        Booking.objects
        .annotate(month=TruncMonth('event_date'))
        .values('month')
        .annotate(
            bookings=Count('book_id'),
            total_revenue=Sum('total_amount')
        )
        .order_by('month')
    )
    return render(request, 'booking/monthly_report.html', {'report_data': report_data})


