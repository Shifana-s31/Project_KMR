from django.conf.urls import url
from notification import views

urlpatterns=[
    url('post_notification/',views.postnotification),
    url('view_notification/',views.Viewnotification),
    url('wr/',views.noti.as_view()),
    url('pp/',views.pp)
]