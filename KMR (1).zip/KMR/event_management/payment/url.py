from django.conf.urls import url
from payment import views
from django.urls import path

urlpatterns=[
    url('view_payment_status/',views.Viewpaymentstatus),
    url('view_payment_status_admin/',views.Viewpaymentstatusadmin),
    # url('calc/', views.calculate_total_payment_view, name='calculate_total_payment'),
    url(r'^calc/(?P<u_id>\d+)/$', views.calculate_total_payment_view, name='calculate_total_payment'),
]