from django.conf.urls import url
from booking import views

urlpatterns=[
    url('post_booking/',views.postbooking),
    url('view_bookg/',views.viewbooking),
    url('bookworker/',views.book_worker.as_view()),
    url('monthly_report/',views.monthly_report)
]