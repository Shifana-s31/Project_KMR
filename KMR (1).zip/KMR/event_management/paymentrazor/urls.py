# payment/urls.py
from django.urls import path
# from .views import payment_form
from paymentrazor import views
from django.conf.urls import url


urlpatterns = [
    # url('payment-form/(?P<idd>\w+)',payment_form),
    path('payment/<int:idd>/', views.payment_form, name='payment_form'),
    path('paymentsingle/<int:idd>/', views.payment_formsingle, name='payment_formsingle'),
    # url('post_pay/',views.update_payment),
]
